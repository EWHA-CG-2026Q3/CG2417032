// Put this file in Assets/S10/Editor/S10_QuickFinishEditor.cs
// Run Tools > S10 > Finish Assignment Setup (while S10_BouncingBallAnimation is open).
// This is an editor-only setup utility. It is not attached to any GameObject.
#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Animations;
using UnityEngine.SceneManagement;

public static class S10_QuickFinishEditor
{
    const string Folder = "Assets/S10";

    [MenuItem("Tools/S10/Finish Assignment Setup")]
    public static void Setup()
    {
        if (EditorApplication.isPlaying)
        {
            EditorUtility.DisplayDialog("S10", "Stop Play mode before running setup.", "OK");
            return;
        }

        Scene scene = SceneManager.GetActiveScene();
        if (!scene.IsValid() || !scene.name.Equals("S10_BouncingBallAnimation", StringComparison.Ordinal))
        {
            EditorUtility.DisplayDialog("S10", "First open Assets/S10/S10_BouncingBallAnimation.unity.", "OK");
            return;
        }

        try
        {
            RepairTable(scene);
            SetupBall();
            SetupDiamonds();
            SetupAnimations();
            SetupCamera();
            EditorSceneManager.MarkSceneDirty(scene);
            AssetDatabase.SaveAssets();
            EditorSceneManager.SaveScene(scene);
            EditorUtility.DisplayDialog("S10", "Setup finished! Press Play and check the moving ball, diamond, and both moons. Record the Game view.", "OK");
        }
        catch (Exception ex)
        {
            Debug.LogException(ex);
            EditorUtility.DisplayDialog("S10 setup failed", ex.Message + "\nSee Console for details.", "OK");
        }
    }

    static Transform Find(string objectName)
    {
        foreach (GameObject root in SceneManager.GetActiveScene().GetRootGameObjects())
        {
            Transform[] nodes = root.GetComponentsInChildren<Transform>(true);
            foreach (Transform t in nodes)
                if (t.name == objectName) return t;
        }
        return null;
    }

    static Transform Need(string name)
    {
        Transform t = Find(name);
        if (t == null)
            t = new GameObject(name).transform;
        return t;
    }

    static void Place(Transform t, Transform parent, Vector3 pos, Vector3 scale)
    {
        if (t.parent != parent)
            Undo.SetTransformParent(t, parent, "S10 Set Hierarchy");
        t.localPosition = pos;
        t.localRotation = Quaternion.identity;
        t.localScale = scale;
        EditorUtility.SetDirty(t);
    }

    static void RepairTable(Scene scene)
    {
        foreach (GameObject root in scene.GetRootGameObjects())
        {
            if (root.name.StartsWith("Table", StringComparison.OrdinalIgnoreCase) &&
                (PrefabUtility.GetPrefabInstanceStatus(root) == PrefabInstanceStatus.MissingAsset ||
                 root.name.Contains("Missing Prefab")))
            {
                Undo.DestroyObjectImmediate(root);
            }
        }

        if (Find("Table") == null)
        {
            GameObject source = AssetDatabase.LoadAssetAtPath<GameObject>(Folder + "/Table.prefab");
            if (source != null)
            {
                GameObject instance = PrefabUtility.InstantiatePrefab(source, scene) as GameObject;
                if (instance != null)
                {
                    instance.name = "Table";
                    instance.transform.position = Vector3.zero;
                    instance.transform.rotation = Quaternion.identity;
                    instance.transform.localScale = Vector3.one;
                }
            }
            else
            {
                Debug.LogWarning("S10: Could not find Assets/S10/Table.prefab. Please drag the Table prefab into the scene manually.");
            }
        }
    }

    static void SetupBall()
    {
        Transform stage = Need("BallStage");
        Transform orbit = Need("Ball_Orbit");
        Transform offset = Need("Ball_Offset");
        Transform sphere = Need("Ball_Sphere");
        Transform mesh = Need("Ball_Mesh");
        Transform moonOrbit = Need("Moon_Orbit");
        Transform moonOffset = Need("Moon_Offset");
        Transform moonSphere = Need("Moon_Sphere");
        Transform moonMesh = Need("Moon_Mesh");

        Place(stage, null, new Vector3(0, 0.78f, 0), Vector3.one);
        Place(orbit, stage, Vector3.zero, Vector3.one);
        Place(offset, orbit, new Vector3(0.5f, 0, 0), Vector3.one);
        Place(sphere, offset, Vector3.zero, Vector3.one * 0.1f);
        Place(mesh, sphere, Vector3.zero, Vector3.one);
        Place(moonOrbit, sphere, Vector3.zero, Vector3.one);
        Place(moonOffset, moonOrbit, new Vector3(1.5f, 0, 0), Vector3.one);
        Place(moonSphere, moonOffset, Vector3.zero, Vector3.one * 0.5f);
        Place(moonMesh, moonSphere, Vector3.zero, Vector3.one);

        // Existing Ball_Mesh and Moon_Mesh are Unity spheres in the supplied scene.
        if (moonMesh.GetComponent<MeshFilter>() == null)
        {
            GameObject temp = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            MeshFilter src = temp.GetComponent<MeshFilter>();
            MeshRenderer srcRenderer = temp.GetComponent<MeshRenderer>();
            MeshFilter dst = Undo.AddComponent<MeshFilter>(moonMesh.gameObject);
            dst.sharedMesh = src.sharedMesh;
            MeshRenderer dstRenderer = Undo.AddComponent<MeshRenderer>(moonMesh.gameObject);
            dstRenderer.sharedMaterial = srcRenderer.sharedMaterial;
            UnityEngine.Object.DestroyImmediate(temp);
        }
    }

    static void SetupDiamonds()
    {
        Transform stage = Need("DiamondStage");
        Transform orbit = Need("Diamond_Orbit");
        Transform offset = Need("Diamond_Offset");
        Transform ball = Need("Diamond_Ball");
        Transform mesh = Need("Diamond_Mesh");
        Transform moonOrbit = Need("Diamond_Moon_Orbit");
        Transform moonOffset = Need("Diamond_Moon_Offset");
        Transform moonSphere = Need("Diamond_Moon_Sphere");
        Transform moonMesh = Need("Diamond_Moon_Mesh");

        Place(stage, null, new Vector3(0, 0.73f, 0.2f), Vector3.one);
        Place(orbit, null, Vector3.zero, Vector3.one);
        Place(offset, null, new Vector3(0.5f, 0, 0), Vector3.one);
        Place(ball, null, Vector3.zero, Vector3.one * 0.1f);
        Place(mesh, null, Vector3.zero, Vector3.one);

        // Source mesh vertices range from (0,0,0) to (1,1,1).
        // Center=(.5,.5,.5); ball scale=.1; moon orbit radius=1.5*.1=.15;
        // moon world scale=.1*.5=.05. Offset vertex center by -.25 after scale .5.
        Place(moonOrbit, null, new Vector3(0.5f, 0.5f, 0.5f), Vector3.one);
        Place(moonOffset, null, new Vector3(1.5f, 0, 0), Vector3.one);
        Place(moonSphere, null, new Vector3(-0.25f, -0.25f, -0.25f), Vector3.one * 0.5f);
        Place(moonMesh, null, Vector3.zero, Vector3.one);

        MakeDiamondMesh(mesh, new [] { stage, orbit, offset, ball });
        MakeDiamondMesh(moonMesh, new [] { stage, orbit, offset, ball, moonOrbit, moonOffset, moonSphere });
    }

    static void MakeDiamondMesh(Transform t, Transform[] chain)
    {
        GameObjectUtility.RemoveMonoBehavioursWithMissingScript(t.gameObject);
        DiamondMesh_Rewinded diamond = t.GetComponent<DiamondMesh_Rewinded>();
        if (diamond == null) diamond = Undo.AddComponent<DiamondMesh_Rewinded>(t.gameObject);
        S10_DiamondChain_Finish processor = t.GetComponent<S10_DiamondChain_Finish>();
        if (processor == null) processor = Undo.AddComponent<S10_DiamondChain_Finish>(t.gameObject);

        SerializedObject obj = new SerializedObject(processor);
        SerializedProperty p = obj.FindProperty("chain");
        if (p == null) throw new Exception("S10_DiamondChain_Finish is missing its serialized field 'chain'.");
        p.arraySize = chain.Length;
        for (int i = 0; i < chain.Length; i++)
            p.GetArrayElementAtIndex(i).objectReferenceValue = chain[i];
        obj.ApplyModifiedProperties();
        EditorUtility.SetDirty(processor);
        EditorUtility.SetDirty(diamond);
    }

    static AnimationClip MakeClip(string shortName, string property, Keyframe[] keys)
    {
        string path = Folder + "/S10_Auto_" + shortName + ".anim";
        AnimationClip clip = AssetDatabase.LoadAssetAtPath<AnimationClip>(path);
        if (clip == null)
        {
            clip = new AnimationClip();
            AssetDatabase.CreateAsset(clip, path);
        }
        clip.frameRate = 60f;
        AnimationCurve curve = new AnimationCurve(keys);
        AnimationUtility.SetEditorCurve(clip,
            EditorCurveBinding.FloatCurve("", typeof(Transform), property), curve);
        clip.wrapMode = WrapMode.Loop;
        SerializedObject so = new SerializedObject(clip);
        SerializedProperty loop = so.FindProperty("m_AnimationClipSettings.m_LoopTime");
        if (loop != null) loop.boolValue = true;
        so.ApplyModifiedProperties();
        EditorUtility.SetDirty(clip);
        return clip;
    }

    static AnimatorController MakeController(string shortName, AnimationClip clip)
    {
        string path = Folder + "/S10_Auto_" + shortName + ".controller";
        AnimatorController controller = AssetDatabase.LoadAssetAtPath<AnimatorController>(path);
        if (controller == null)
            controller = AnimatorController.CreateAnimatorControllerAtPath(path);
        AnimatorStateMachine sm = controller.layers[0].stateMachine;
        AnimatorState state = null;
        foreach (ChildAnimatorState child in sm.states)
            if (child.state.name == "Loop") { state = child.state; break; }
        if (state == null) state = sm.AddState("Loop");
        state.motion = clip;
        sm.defaultState = state;
        EditorUtility.SetDirty(controller);
        return controller;
    }

    static void Assign(string objectName, RuntimeAnimatorController controller)
    {
        Transform node = Need(objectName);
        Animator a = node.GetComponent<Animator>();
        if (a == null) a = Undo.AddComponent<Animator>(node.gameObject);
        a.runtimeAnimatorController = controller;
        a.applyRootMotion = false;
        a.cullingMode = AnimatorCullingMode.AlwaysAnimate;
        a.enabled = true;
        EditorUtility.SetDirty(a);
    }

    static void SetupAnimations()
    {
        AnimationClip orbit = MakeClip("BallOrbit", "localEulerAnglesRaw.y", new [] {
            new Keyframe(0f, 0f, 90f, 90f), new Keyframe(4f, 360f, 90f, 90f) });
        AnimationClip bouncing = MakeClip("Bounce", "m_LocalPosition.y", new [] {
            new Keyframe(0f, 0f, -3f, 3f),
            new Keyframe(20f / 60f, 1f, 0f, 0f),
            new Keyframe(40f / 60f, 0f, -3f, 3f) });
        AnimationClip moon = MakeClip("MoonOrbit", "localEulerAnglesRaw.y", new [] {
            new Keyframe(0f, 0f, 180f, 180f), new Keyframe(2f, 360f, 180f, 180f) });
        AnimatorController orbitCtrl = MakeController("BallOrbit", orbit);
        AnimatorController bounceCtrl = MakeController("Bounce", bouncing);
        AnimatorController moonCtrl = MakeController("MoonOrbit", moon);

        Assign("Ball_Orbit", orbitCtrl);
        Assign("Ball_Sphere", bounceCtrl);
        Assign("Moon_Orbit", moonCtrl);
        Assign("Diamond_Orbit", orbitCtrl);
        Assign("Diamond_Ball", bounceCtrl);
        Assign("Diamond_Moon_Orbit", moonCtrl);
    }

    static void SetupCamera()
    {
        Transform t = Find("Main Camera");
        if (t == null) return;
        LookAtConstraint constraint = t.GetComponent<LookAtConstraint>();
        if (constraint != null)
        {
            // Original uploaded scene had an unassigned LookAt target.
            constraint.constraintActive = false;
            constraint.enabled = false;
        }
        t.position = new Vector3(1.65f, 1.7f, -2.8f);
        t.LookAt(new Vector3(0, 0.75f, 0.05f), Vector3.up);
        Camera cam = t.GetComponent<Camera>();
        if (cam != null) cam.fieldOfView = 52f;
        EditorUtility.SetDirty(t);
    }
}
#endif
